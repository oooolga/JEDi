<p align="center">
<a href="https://oooolga.github.io/ctrl-v.github.io/">
    <picture>
        <img alt="logo" src="./assets/logo.png" height="80">
    </picture>
</a>
</p>

# Beyond FVD: Enhanced Evaluation Metrics for Video Generation Quality

<p align="left">
<a href="https://oooolga.github.io/JEDi.github.io/" alt="webpage">
    <img src="https://img.shields.io/badge/Webpage-JEDi-darkviolet" /></a>
<img src="https://img.shields.io/github/license/oooolga/JEDi" />
<img src="https://views.whatilearened.today/views/github/oooolga/JEDi.svg" />
<p align="center">
<picture>
  <img src="./assets/teaser_plot.png">
</picture>
</p>